import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    System.out.println("Escriu alguna cosa"); // imprime un mensaje}}
    String mensaje=sc.nextLine();
    System.out.println(mensaje); // imprime un mensaje}}
  }
}
