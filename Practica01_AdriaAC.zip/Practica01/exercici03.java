import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner sc=new Scanner(System.in);
    System.out.print("Escriu la teva edat: "); // imprime un mensaje}}
    int edat=sc.nextInt();
    edat= edat + 1;
    System.out.print("L'any que ve tindras "+ edat +" anys"); // imprime un mensaje}}
  }
}
